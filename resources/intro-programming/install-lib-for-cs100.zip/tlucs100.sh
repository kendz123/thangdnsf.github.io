#!/bin/sh
wget https://thangdnsf.github.io/resources/intro-programming/stdlib-python.zip
unzip stdlib-python.zip
cp -r stdlib-python/* /usr/local/lib/python3.6/dist-packages
cp -r stdlib-python/* /usr/local/lib/python3.5/dist-packages
cp -r stdlib-python/* /usr/local/lib/python2.7/dist-packages
rm stdlib-python.zip
rm -r stdlib-python
