#!/bin/sh
dpkg -i python3-pip_8.1.1-2ubuntu0.4_all.deb
dpkg -i python3-tk_3.5.1-1_i386.deb
dpkg -i python3-pygame_1.9.3+dfsg-2+b1_i386.deb
